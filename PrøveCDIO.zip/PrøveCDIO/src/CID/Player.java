package CID;

import java.util.Scanner;

public class Player {
    public static String input() {
        Scanner scannerTo = new Scanner(System.in);
        String startKnap = scannerTo.next();
        return startKnap;
    }
    public static String getName(){
        Scanner scanner = new Scanner(System.in);

        String spillerNavn = scanner.next();
        return spillerNavn;

    }









    int diceAmount;
    int winningCondition;
    int diceMin;
    int diceMax;


    Player()
    {
        diceAmount = 2;
        winningCondition = 3000;
        diceMin = 1;
        diceMax = 6;
    }













}
