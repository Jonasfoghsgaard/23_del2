package CID;
public class Bank {
        public static int konto(int valueOfdice) {
            Dice roll = new Dice();
           int point = PointTable.PointTable(roll.diceSum);
           int Account =  point;
           return Account;
        }
    }