package CID;

import java.util.zip.DeflaterInputStream;

public class Out {

    public static void main(String[] args) {

        Player player = new Player();

        int sumet=1000;
        int sumto = 1000;
        String SpillerEt = Player.getName();
        String SpillerTo = Player.getName();

        while (sumet < player.winningCondition && sumto <player.winningCondition) {
            Dice roll = new Dice();
            Dice roll1 = new Dice();
            sumet = sumet + PointTable.PointTable(roll.diceSum);
            sumto = sumto + PointTable.PointTable(roll1.diceSum);

            //System.out.println(SpillerEt + " du skal indtaste et tegn, for at slå med terningerne");
           // System.out.println("Du tastede " + Player.input() + " så slår vi med terningerne");

            System.out.println(SpillerEt + " slår med terningerne " +roll.dice1 +" " +roll.dice2+" " + "og slår ialt: " + roll.diceSum);
            System.out.println(TextTable.Text(roll.diceSum));
            System.out.println(PointTable.PointTable(roll.diceSum));
            System.out.println(SpillerEt + " har nu " + sumet);
            System.out.println("----------------------------------------------------------------");

            while (roll.diceSum == 10){
                Dice slå = new Dice();
                sumet = sumet + PointTable.PointTable(slå.diceSum);


                System.out.println(SpillerEt + " slår med terningerne" +slå.dice1 +" " +slå.dice2+" " + "og slår ialt: " + slå.diceSum);
                System.out.println(TextTable.Text(slå.diceSum));
                System.out.println(PointTable.PointTable(slå.diceSum));
                System.out.println(SpillerEt + " har nu " + sumet);
                System.out.println("----------------------------------------------------------------");
                break;

                }
            if (sumet >= player.winningCondition){
                System.out.println(SpillerEt + " Vandt!");
            }
            //System.out.println(SpillerTo + " du skal indtaste et tegn, for at slå med terningerne");
            //System.out.println("Du tastede " + Player.input() + " så slår vi med terningerne");

            System.out.println(SpillerTo + " slår med terningerne " +roll1.dice1 +" " +roll1.dice2+" " + "og slår ialt: " + roll1.diceSum);
            System.out.println(TextTable.Text(roll1.diceSum));
            System.out.println(PointTable.PointTable(roll1.diceSum));
            System.out.println(SpillerTo + " har nu " + sumto);
            System.out.println("----------------------------------------------------------------");

            while (roll1.diceSum == 10){
                Dice roll2 = new Dice();
                sumto = sumto + PointTable.PointTable(roll2.diceSum);
                System.out.println(SpillerTo + " slår med terningerne " +roll2.dice1 +" " +roll2.dice2+" " + "og slår ialt: " + roll2.diceSum);
                System.out.println(TextTable.Text(roll2.diceSum));
                System.out.println(PointTable.PointTable(roll2.diceSum));
                System.out.println(SpillerTo + " har nu " + sumto);
                System.out.println("----------------------------------------------------------------");
                break;
            }
            if (sumto>= player.winningCondition){
                System.out.println(SpillerTo + " Vandt!");
            }
        }

    }
}