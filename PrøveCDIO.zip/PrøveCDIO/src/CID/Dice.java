package CID;

import java.util.concurrent.ThreadLocalRandom;
    public class Dice {

        static Player player = new Player();



    int diceSum;
    int dice1;
    int dice2;




        private static int roll() {
        return ThreadLocalRandom.current().nextInt(player.diceMin, player.diceMax + 1);
    }



    private static int getSum(int n1, int n2){
        return n1+n2;
    }

    public Dice(){
        dice1 = roll();
        dice2 = roll();
        diceSum = Dice.getSum(dice1  ,dice2);


    }
}
