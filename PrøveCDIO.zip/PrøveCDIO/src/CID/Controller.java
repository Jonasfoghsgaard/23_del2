










/*package src;

public class Controller {

       static Bank point = new Bank();
       static Player player = new Player();
    public static void main(String[] args) {

        int sumEt = point.Account;
        int sumTo = point.Account;

        System.out.println("Velkommen til terning og felter 2.0!");
        System.out.println("Indtast venligst navnet på spiller et:");
        String SpillerEt = Player.getName();
        System.out.println("Indtast venligst navnet på spiller to:");
        String SpillerTo = Player.getName();
        System.out.println("Let the games begin:");


        while (player.winningCondition > sumEt && player.winningCondition > sumTo) {

            Dice roll = new Dice();

            sumEt = sumEt + (PointTable.PointTable(roll.diceSum));
            sumTo = sumTo + (PointTable.PointTable(roll.diceSum2));


            System.out.println(SpillerEt + " du skal indtaste et tegn, for at slå med terningerne");
            System.out.println("Du tastede " + Player.input() + " så slår vi med terningerne");


            System.out.println(roll.dice1 + " " + roll.dice2);
            System.out.println(SpillerEt + " slår med terningerne, og slår ialt: " + roll.diceSum);
            System.out.println(TextTable.Text(roll.diceSum));
            System.out.println(PointTable.PointTable(roll.diceSum));
            System.out.println(SpillerEt + " har nu " + sumEt + " point");
            System.out.println("----------------------------------------------------------------");



            System.out.println(SpillerTo + " du skal indtaste et tegn, for at slå med terningerne");
            System.out.println("Du tastede " + Player.input() + " så slår vi med terningerne");

            System.out.println(roll.dice3 + " " + roll.dice4);
            System.out.println(SpillerTo + " slår med terningerne, og slår ialt: " + roll.diceSum2);

            System.out.println(TextTable.Text(roll.diceSum2));
            System.out.println(PointTable.PointTable(roll.diceSum2));
            System.out.println(SpillerTo + " har nu " + sumTo + " point");
            System.out.println("----------------------------------------------------------------");



            }
        }


    }




*/